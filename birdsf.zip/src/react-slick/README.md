# Installation
> `npm install --save @types/react-slick`

# Summary
This package contains type definitions for react-slick (https://github.com/akiran/react-slick).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-slick.

### Additional Details
 * Last updated: Thu, 23 Dec 2021 23:35:41 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: none

# Credits
These definitions were written by [Giedrius Grabauskas](https://github.com/GiedriusGrabauskas), [Andrew Makarov](https://github.com/r3nya), and [Shannor Trotty](https://github.com/Shannor).
